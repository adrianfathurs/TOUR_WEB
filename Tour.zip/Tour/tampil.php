<?php
	include "koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Tampil Komentar</title>
	<link rel="stylesheet" href="css/bootstrap.min.css" >
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<style type="text/css">
	.txtaction{
		text-align:center; 
	}
.logo{
		height:50px;
		width:50px;
	}
</style>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  		<image class=" Navbar-brand logo" src="image/logo3.jpg"/>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    	<span class="navbar-toggler-icon"></span>
  		</button>
  
  	<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    	<div class="navbar-nav">
      	<a class="nav-item nav-link active" href="Halamanutama.php">Home <span class="sr-only">(current)</span></a>
      	<a class="nav-item nav-link" href="form.php">Komentar</a>
      	<a class="nav-item nav-link" href="tampil.php">Dokumentasi Komentar</a>
      	<a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
    	</div>
  	</div>
	</nav>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">ID_KTP</th>
      <th scope="col">NAMA LENGKAP</th>
      <th scope="col">EMAIL</th>
      <th scope="col">KOMENTAR</th>
      <th scope="col" colspan="2"><p><span class="txtaction">Action</span></p></th>
    </tr>
  </thead>
  <tbody>
    <?php
    	$query=mysqli_query($conn,"SELECT * from komentar");
    	while($data=mysqli_fetch_array($query))
    	{
    ?>
   			 <tr>
      			
     			<td><?php echo $data['id_ktp']?></td>
     			<td><?php echo $data['Nama']?></td>
     			<td><?php echo $data['email']?></td>
     			<td><?php echo $data['Komentar']?></td>	
     			<td><a href=hapus.php?idktp=<?php echo $data['id_ktp'];?>>Hapus</a></td>	
     			<td><a href=edit.php?id_ktp=<?php echo $data['id_ktp'];?>>Edit</a></td>	

    		 </tr>
    <?php
		}
    ?>
  </tbody>
</table>
</body>
</html>