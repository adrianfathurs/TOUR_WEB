
<?php
include "koneksi.php";

$id_ktp=$_GET['idktp'];
$nama=$_GET['nama'];
$email=$_GET['email'];
$komentar=$_GET['komentar'];

$query=mysqli_query($conn,"UPDATE komentar SET id_ktp='$id_ktp',Nama='$nama',email='$email',Komentar='$komentar' where id_ktp='$id_ktp'") or die(mysqli_error($conn));
	
	if($query)
	{
		echo include "tampil.php";
	}
	else
	{
		echo "gagal edit";
	}
?>