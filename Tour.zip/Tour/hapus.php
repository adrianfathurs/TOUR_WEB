<?php
include "koneksi.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
	
$id_ktp=$_GET['idktp'];
	
$sql="DELETE from komentar where id_ktp='$id_ktp'";
$query=mysqli_query($conn,$sql);

if($query)
{
	echo include "tampil.php";
	echo $id_ktp ?><br><p>Sudah di Hapus</p>;<?php
}
else
{
	echo "gagal";
}
?>
</body>
</html>
