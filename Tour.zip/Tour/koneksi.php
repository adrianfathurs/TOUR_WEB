<?php
	$dbservername="localhost";
	$dbusername="root";
	$dbpassword="";
	$dbdatabase="tour";

	$conn=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbdatabase);
	if ($conn->connect_error)
	{
		die('Maaf koneksi gagal'.connect_error);
	}
?>