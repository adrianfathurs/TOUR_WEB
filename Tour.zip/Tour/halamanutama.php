<!DOCTYPE html>
<html>
<head>
	<title>Da Tour</title>
	<link rel="stylesheet" href="css/bootstrap.min.css" >
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<style type="text/css">
	.jumbotron{
		
	background: url(image/indonesiaview.jpg);
	position: relative;
	width: 1250;
	height:600 ;
	background-size: cover;
	overflow: hidden;

	}

	.btnletsgo{
		
	font-weight: bold;
	font-family: Arial Rounded MT Bold;
	color: #FFF8DC;
		}
	
	.backgroundbtnletsgo
	{	
	margin-top: 80px;
	background: transparent;
	margin: center;

	}

	..backgroundbtnborobudur
	{	
	margin-top: 100px;
	background:  #FF7F50;
	margin: center;

	}

	.layout{

	text-align: center;
	font-family: Script MT Bold;
	}

	.ukuran{
	width: 450px;
	height: 350px;
	border-radius: 30px;
	margin-top: 20px;
	margin-left: 70px;
	margin-bottom: 30px;
	}

	.borobudurword{
		margin-left: 20px;
		text-align: justify;
	}

	.readtanahlot
	{
		margin-top: 10px;
		margin-right: 50px;
		margin-left: 60px;

	}

	.logo{
		height:50px;
		width:50px;
	}
</style>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  		<image class=" Navbar-brand logo" src="image/logo3.jpg"/>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    	<span class="navbar-toggler-icon"></span>
  		</button>
  
  	<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    	<div class="navbar-nav">
      	<a class="nav-item nav-link active" href="halamanutama.php">Home <span class="sr-only">(current)</span></a>
      	<a class="nav-item nav-link" href="form.php">Komentar</a>
      	<a class="nav-item nav-link" href="tampil.php">Dokumentasi Komentar</a>
      	<a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
    	</div>
  	</div>
	</nav>
<!--Pemberian background HalamanUtama  -->
	<div class="jumbotron jumbotron-fluid">
  		<h1 class="display-4 layout">Hello, Indonesia!</h1>
  		<p class="lead layout">”Life is short and the world is wide”</p>
  		<center><a class="btn btn-lg btn-warning backgroundbtnletsgo" href="#" role="button"><span class="btnletsgo">Let's Go</span></a><center>
	</div>
<!-- Pembuatan Isi web -->
	<div class="container-fluid bg-light">
		<div class="row">
			<div class="col-md-6 bg-dark">
			<img class="ukuran" src="image/borobudur.jpg">
			</div>	

			<div class="col-md-6">
			<p class="readborobudur">
				<span class="borobudurword"><strong>Borobudur</strong></span> is only one hour’s drive from Yogyakarta. The easiest way to get there is by joining a tour or renting a car. During your journey to Borobudur, enjoy the fresh cool air of Magelang city with its roads lined with big shady trees. Borobudur itself stands tall against the spectacular backdrop of the Menoreh mountain range that surrounds it.

				Entering the temple compound is easy and most visitors choose to wander around on foot. Alternatively, you can chart a cart (pulled by a horse) at a reasonable price. Alternatively, cruise passengers who disembark at Semarang can take a day tour driving through Wonosobo to Borobudur. </p>
		
			<center><a class="btn btn-lg btn-warning backgroundbtnborobudur" href="#" role="button"><span class="btnletsgo">Borobudur</span></a><center>
				
			

		</div>
	</div>
	</div>

			
			<div class="container-fluid bg-dark">
		<div class="row">
			<div class="col-md-6 bg-light">

<p class=" readtanahlot">
<span class="borobudurword">Tanah Lot</span> adalah daerah tujuan wisata yang sangat terkenal di dunia, dan menjadi salah satu obyek wisata terbaik di pulau Bali serta salah satu tempat wisata favorit untuk menikmati keindahan sunset/matahari tenggelam di pulau dewata. Setiap hari objek wisata ini dikunjungi oleh ribuan wisatawan baik wisatawan domestik maupun wisatawan mancanegara. </p>

			
			<center><a class="btn btn-lg btn-warning backgroundbtnborobudur" href="#" role="button"><span class="btnletsgo">Tanah Lot</span></a><center>
			</div>	

			<div class="col-md-6">
				<img class="ukuran" src="image/tanahlot.jpg">
				
				
			</div>


		</div>

		</div>




</body>
</html>